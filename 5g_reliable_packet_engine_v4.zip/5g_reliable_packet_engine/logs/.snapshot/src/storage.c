/* storage.c - safe save/load of station records. */
#include <stdio.h>
#include <string.h>
#include "storage.h"
#include "input.h"

typedef struct {
    FILE    *file;
    status_t status;
} save_ctx_t;

static void save_visitor(const station_t *s, void *context)
{
    save_ctx_t *ctx = (save_ctx_t *)context;

    if (ctx->status == STATUS_OK) {
        if (fprintf(ctx->file, "%u|%s|%u|%u|%u|%s\n", (unsigned)s->id, s->name,
                    (unsigned)s->distance_km, (unsigned)s->fare,
                    (unsigned)s->platform, s->type) < 0) {
            ctx->status = STATUS_ERR_IO;
        }
    }
}

status_t storage_save(const bst_t *tree, const char *path)
{
    status_t rc;

    if ((tree == NULL) || (path == NULL)) {
        rc = STATUS_ERR_NULL;
    } else {
        char tmp_path[256];
        size_t len = strlen(path);

        if ((len == 0U) || (len > (sizeof(tmp_path) - 5U))) {
            rc = STATUS_ERR_RANGE;
        } else {
            save_ctx_t ctx;

            (void)memcpy(tmp_path, path, len);
            (void)memcpy(&tmp_path[len], ".tmp", 5U);   /* includes NUL */
            ctx.file = fopen(tmp_path, "w");
            if (ctx.file == NULL) {
                rc = STATUS_ERR_IO;
            } else {
                ctx.status = STATUS_OK;
                if (fprintf(ctx.file, "%s\n", STORAGE_HEADER) < 0) {
                    ctx.status = STATUS_ERR_IO;
                }
                /* Preorder keeps the tree shape when the file is loaded again. */
                rc = bst_preorder(tree, save_visitor, &ctx);
                if (rc == STATUS_OK) {
                    rc = ctx.status;
                }
                if (fclose(ctx.file) != 0) {
                    rc = STATUS_ERR_IO;
                }
                if (rc != STATUS_OK) {
                    (void)remove(tmp_path);
                } else {
                    /* rename() will not overwrite on Windows: remove old file first. */
                    (void)remove(path);
                    if (rename(tmp_path, path) != 0) {
                        rc = STATUS_ERR_IO;
                    }
                }
            }
        }
    }
    return rc;
}

/* Splits "a|b|c|..." in place into `expected` fields: exactly expected-1
 * separators are required. */
static status_t split_fields(char *line, char *fields[], size_t expected)
{
    status_t rc = STATUS_OK;
    size_t idx = 0U;
    size_t pos = 0U;

    fields[0] = line;
    while ((line[pos] != '\0') && (rc == STATUS_OK)) {
        if (line[pos] == '|') {
            line[pos] = '\0';
            idx++;
            if (idx >= expected) {
                rc = STATUS_ERR_FORMAT;
            } else {
                fields[idx] = &line[pos + 1U];
            }
        }
        pos++;
    }
    if ((rc == STATUS_OK) && (idx != (expected - 1U))) {
        rc = STATUS_ERR_FORMAT;
    }
    return rc;
}

/* Record layout: id | name | distance_km | fare | platform | type */
static status_t parse_record(char *line, station_t *out)
{
    char *f[STORAGE_FIELDS];
    status_t rc = split_fields(line, f, STORAGE_FIELDS);

    if (rc == STATUS_OK) {
        uint32_t id = 0U;
        uint32_t dist = 0U;
        uint32_t fare = 0U;
        uint32_t platform = 0U;

        if ((input_parse_u32(f[0], STATION_ID_MIN, STATION_ID_MAX, &id) != STATUS_OK) ||
            (input_parse_u32(f[2], 0U, STATION_DISTANCE_MAX, &dist) != STATUS_OK) ||
            (input_parse_u32(f[3], 0U, STATION_FARE_MAX, &fare) != STATUS_OK) ||
            (input_parse_u32(f[4], STATION_PLATFORM_MIN, STATION_PLATFORM_MAX,
                             &platform) != STATUS_OK)) {
            rc = STATUS_ERR_FORMAT;
        } else {
            rc = station_init(out, id, f[1], dist, fare, platform, f[5]);
        }
    }
    return rc;
}

/* Reads and validates every record of an open file into *loaded. */
static status_t read_records(FILE *file, bst_t *loaded)
{
    char line[STORAGE_LINE_MAX];
    status_t rc = STATUS_OK;
    bool header_seen = false;

    while ((rc == STATUS_OK) && (fgets(line, (int)sizeof(line), file) != NULL)) {
        size_t len = strlen(line);

        if ((len > 0U) && (line[len - 1U] == '\n')) {
            line[len - 1U] = '\0';
            len--;
        } else if (len == (sizeof(line) - 1U)) {
            rc = STATUS_ERR_FORMAT;        /* line longer than the buffer */
        } else {
            /* final line without newline: fine */
        }
        if (rc == STATUS_OK) {
            if ((len > 0U) && (line[len - 1U] == '\r')) {
                line[len - 1U] = '\0';
                len--;
            }
            if ((len == 0U) || (line[0] == '#')) {
                /* blank line or comment: ignored */
            } else if (!header_seen) {
                rc = (strcmp(line, STORAGE_HEADER) == 0) ? STATUS_OK : STATUS_ERR_FORMAT;
                header_seen = true;
            } else {
                station_t st;

                rc = parse_record(line, &st);
                if (rc == STATUS_OK) {
                    rc = bst_insert(loaded, &st);   /* rejects duplicates / overflow */
                }
            }
        }
    }
    if ((rc == STATUS_OK) && (ferror(file) != 0)) {
        rc = STATUS_ERR_IO;
    }
    if ((rc == STATUS_OK) && (!header_seen)) {
        rc = STATUS_ERR_FORMAT;            /* empty or header-less file */
    }
    return rc;
}

status_t storage_load(bst_t *tree, const char *path)
{
    status_t rc;

    if ((tree == NULL) || (path == NULL)) {
        rc = STATUS_ERR_NULL;
    } else {
        FILE *file = fopen(path, "r");

        if (file == NULL) {
            rc = STATUS_ERR_IO;
        } else {
            bst_t loaded;

            bst_init(&loaded);
            rc = read_records(file, &loaded);
            (void)fclose(file);
            if (rc != STATUS_OK) {
                bst_destroy(&loaded);          /* all-or-nothing */
            } else {
                bst_destroy(tree);
                *tree = loaded;
            }
        }
    }
    return rc;
}
