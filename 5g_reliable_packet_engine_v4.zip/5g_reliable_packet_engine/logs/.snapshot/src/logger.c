/* logger.c - timestamped, injectable-clock logger (no global state).
 * Default time zone: Indian Standard Time (IST, UTC+05:30). */
/* gmtime_r needs _POSIX_C_SOURCE=200809L: it is passed by the Makefile (CSTD). */
#include <stdarg.h>
#include <string.h>
#include <time.h>
#include "logger.h"

#define MS_PER_SEC 1000U
#define IST_OFFSET_SEC 19800LL   /* India Standard Time = UTC+05:30, no DST */

uint64_t logger_now_ms(void)
{
    uint64_t now_ms = 0U;
    struct timespec ts;

    if (timespec_get(&ts, TIME_UTC) == TIME_UTC) {
        now_ms = ((uint64_t)ts.tv_sec * (uint64_t)MS_PER_SEC) +
                 ((uint64_t)ts.tv_nsec / 1000000U);
    }
    return now_ms;
}

/* Thread-safe broken-down time; true on success.
 * use_utc == true  -> UTC
 * use_utc == false -> Indian Standard Time (UTC+05:30), independent of the
 *                     machine's TZ setting (India has no daylight saving). */
static bool break_down(time_t seconds, bool use_utc, struct tm *out)
{
    bool ok;
    time_t shifted = use_utc ? seconds : (time_t)((long long)seconds + IST_OFFSET_SEC);

#if defined(_WIN32)
    ok = (gmtime_s(out, &shifted) == 0);
#else
    ok = (gmtime_r(&shifted, out) != NULL);
#endif
    return ok;
}

status_t logger_format_time(uint64_t epoch_ms, bool use_utc, char *buffer,
                            size_t capacity)
{
    status_t rc = STATUS_OK;

    if (buffer == NULL) {
        rc = STATUS_ERR_NULL;
    } else if (capacity < LOGGER_TS_LEN) {
        rc = STATUS_ERR_RANGE;
    } else {
        struct tm parts;
        time_t seconds = (time_t)(epoch_ms / MS_PER_SEC);
        unsigned millis = (unsigned)(epoch_ms % MS_PER_SEC);

        (void)memset(&parts, 0, sizeof(parts));
        buffer[0] = '\0';
        if (!break_down(seconds, use_utc, &parts)) {
            rc = STATUS_ERR_RANGE;
        } else if (strftime(buffer, capacity, "%Y-%m-%d %H:%M:%S", &parts) != 19U) {
            buffer[0] = '\0';
            rc = STATUS_ERR_RANGE;
        } else {
            size_t used = strlen(buffer);

            if (snprintf(&buffer[used], capacity - used, ".%03u", millis) != 4) {
                buffer[0] = '\0';
                rc = STATUS_ERR_RANGE;
            }
        }
    }
    return rc;
}

status_t logger_timestamp(char *buffer, size_t capacity)
{
    return logger_format_time(logger_now_ms(), false, buffer, capacity);
}

const char *logger_level_name(log_level_t level)
{
    const char *name = "UNKNOWN";

    switch (level) {
    case LOG_DEBUG: name = "DEBUG"; break;
    case LOG_INFO:  name = "INFO "; break;
    case LOG_WARN:  name = "WARN "; break;
    case LOG_ERROR: name = "ERROR"; break;
    default:        break;
    }
    return name;
}

status_t logger_init(logger_t *logger, FILE *file, FILE *console,
                     log_level_t min_level)
{
    status_t rc = STATUS_OK;

    if (logger == NULL) {
        rc = STATUS_ERR_NULL;
    } else if ((min_level < LOG_DEBUG) || (min_level > LOG_ERROR)) {
        rc = STATUS_ERR_RANGE;
    } else {
        (void)memset(logger, 0, sizeof(*logger));
        logger->file = file;
        logger->console = console;
        logger->min_level = min_level;
        logger->clock = logger_now_ms;
        logger->use_utc = false;
        logger->owns_file = false;
        logger->lines = 0U;
    }
    return rc;
}

status_t logger_open(logger_t *logger, const char *path, FILE *console,
                     log_level_t min_level)
{
    status_t rc;

    if ((logger == NULL) || (path == NULL)) {
        rc = STATUS_ERR_NULL;
    } else {
        FILE *file = fopen(path, "a");

        if (file == NULL) {
            rc = STATUS_ERR_IO;
        } else {
            rc = logger_init(logger, file, console, min_level);
            if (rc == STATUS_OK) {
                logger->owns_file = true;
            } else {
                (void)fclose(file);
            }
        }
    }
    return rc;
}

void logger_set_clock(logger_t *logger, logger_clock_fn clock_fn)
{
    if (logger != NULL) {
        logger->clock = (clock_fn != NULL) ? clock_fn : logger_now_ms;
    }
}

void logger_set_utc(logger_t *logger, bool use_utc)
{
    if (logger != NULL) {
        logger->use_utc = use_utc;
    }
}

/* Replaces control characters so one call always yields exactly one line. */
static void sanitize_line(char *text)
{
    size_t i;

    for (i = 0U; text[i] != '\0'; i++) {
        if ((text[i] == '\n') || (text[i] == '\r')) {
            text[i] = ' ';
        }
    }
}

static void write_record(FILE *stream, const char *record)
{
    if (stream != NULL) {
        (void)fprintf(stream, "%s\n", record);
        (void)fflush(stream);
    }
}

status_t logger_log(logger_t *logger, log_level_t level, const char *module,
                    const char *fmt, ...)
{
    status_t rc = STATUS_OK;

    if ((logger == NULL) || (module == NULL) || (fmt == NULL)) {
        rc = STATUS_ERR_NULL;
    } else if ((level < LOG_DEBUG) || (level > LOG_ERROR)) {
        rc = STATUS_ERR_RANGE;
    } else if ((level >= logger->min_level) &&
               ((logger->file != NULL) || (logger->console != NULL))) {
        char stamp[LOGGER_TS_LEN];

        rc = logger_format_time((logger->clock != NULL) ? logger->clock() : 0U,
                                logger->use_utc, stamp, sizeof(stamp));
        if (rc == STATUS_OK) {
            char message[LOGGER_MESSAGE_MAX];
            char record[LOGGER_MESSAGE_MAX + LOGGER_TS_LEN + LOGGER_MODULE_MAX + 16U];
            va_list args;
            int written;

            va_start(args, fmt);
            written = vsnprintf(message, sizeof(message), fmt, args);
            va_end(args);
            if (written < 0) {
                rc = STATUS_ERR_FORMAT;
            } else {
                sanitize_line(message);
                (void)snprintf(record, sizeof(record), "%s | %s | %-*.*s | %s", stamp,
                               logger_level_name(level), (int)LOGGER_MODULE_MAX - 1,
                               (int)LOGGER_MODULE_MAX - 1, module, message);
                write_record(logger->file, record);
                write_record(logger->console, record);
                logger->lines++;
            }
        }
    } else {
        /* filtered out by level, or no sink attached: nothing to do */
    }
    return rc;
}

void logger_close(logger_t *logger)
{
    if (logger != NULL) {
        if ((logger->file != NULL) && logger->owns_file) {
            (void)fclose(logger->file);
        }
        logger->file = NULL;
        logger->console = NULL;
        logger->owns_file = false;
    }
}
