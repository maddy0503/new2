/* test_sliding_window.c - Go-Back-N unit and functional tests. */
#include <string.h>
#include "test_framework.h"
#include "sliding_window.h"

#define SRC 101U
#define DST 202U

static sw_config_t cfg(uint8_t window, uint32_t packets)
{
    sw_config_t c;
    (void)sw_config_default(&c);
    c.window_size = window;
    c.packet_count = packets;
    c.data_loss_every = 0U;
    c.ack_loss_every = 0U;
    return c;
}

static void test_config_validation(void)
{
    sw_config_t c = cfg(4U, 10U);
    CHECK(sw_config_validate(&c) == STATUS_OK);
    CHECK(sw_config_validate(NULL) == STATUS_ERR_NULL);
    c = cfg(0U, 10U);  CHECK(sw_config_validate(&c) == STATUS_ERR_RANGE);   /* invalid window */
    c = cfg(16U, 10U); CHECK(sw_config_validate(&c) == STATUS_ERR_RANGE);   /* >= modulus */
    c = cfg(15U, 10U); CHECK(sw_config_validate(&c) == STATUS_OK);          /* boundary */
    c = cfg(4U, 0U);   CHECK(sw_config_validate(&c) == STATUS_ERR_RANGE);   /* zero packets */
    c = cfg(4U, SW_MAX_PACKETS + 1U); CHECK(sw_config_validate(&c) == STATUS_ERR_RANGE);
    c = cfg(4U, 10U); c.timeout_ticks = 0U;  CHECK(sw_config_validate(&c) == STATUS_ERR_RANGE);
    c = cfg(4U, 10U); c.max_retries = 0U;    CHECK(sw_config_validate(&c) == STATUS_ERR_RANGE);
    c = cfg(4U, 10U); c.data_loss_percent = 101U; CHECK(sw_config_validate(&c) == STATUS_ERR_RANGE);
    CHECK(sw_config_default(NULL) == STATUS_ERR_NULL);
}

static void test_invalid_packet_count_and_window_in_simulation(void)
{
    sw_stats_t st; sw_config_t c;
    c = cfg(4U, 0U);  CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_ERR_RANGE);
    CHECK(st.delivered == 0U);
    c = cfg(0U, 5U);  CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_ERR_RANGE);
    c = cfg(4U, 5U);
    CHECK(sw_simulate(NULL, SRC, DST, NULL, &st) == STATUS_ERR_NULL);
    CHECK(sw_simulate(&c, SRC, DST, NULL, NULL) == STATUS_ERR_NULL);
    CHECK(sw_simulate(&c, 0U, DST, NULL, &st) == STATUS_ERR_RANGE);
}

static void test_fewer_than_window(void)
{
    sw_config_t c = cfg(8U, 3U); sw_stats_t st;
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_OK);
    CHECK(st.delivered == 3U && st.data_tx == 3U && st.retransmissions == 0U);
    CHECK(st.timeouts == 0U && st.acks_received == 3U);
}

static void test_exactly_window(void)
{
    sw_config_t c = cfg(4U, 4U); sw_stats_t st;
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_OK);
    CHECK(st.delivered == 4U && st.data_tx == 4U && st.retransmissions == 0U);
}

static void test_more_than_window_no_loss(void)
{
    sw_config_t c = cfg(3U, 20U); sw_stats_t st;
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_OK);
    CHECK(st.delivered == 20U && st.data_tx == 20U);
    CHECK(st.data_lost == 0U && st.duplicates == 0U && st.out_of_order == 0U);
}

static void test_flow_control_sender_window(void)
{
    sw_sender_t s; packet_t *p = NULL; uint32_t adv = 99U;
    uint8_t pl[4] = {1U, 2U, 3U, 4U}; uint32_t i;
    CHECK(sw_sender_init(&s, 3U, 10U, SRC, DST) == STATUS_OK);
    for (i = 0U; i < 3U; i++) {
        CHECK(sw_sender_can_send(&s));
        CHECK(sw_sender_next_packet(&s, pl, 4U, 0U, &p) == STATUS_OK);
        CHECK(p != NULL && p->seq == (uint8_t)i);
    }
    CHECK(!sw_sender_can_send(&s));                         /* window full */
    CHECK(sw_sender_next_packet(&s, pl, 4U, 0U, &p) == STATUS_ERR_FULL);
    CHECK(sw_sender_outstanding(&s) == 3U);
    /* cumulative ACK 2 -> packets 0 and 1 acknowledged */
    CHECK(sw_sender_process_ack(&s, 2U, 3U, &adv) == STATUS_OK);
    CHECK(adv == 2U && s.base_abs == 2U && sw_sender_outstanding(&s) == 1U);
    CHECK(s.slots[0].status == PKT_STATUS_ACKED);
    CHECK(sw_sender_can_send(&s));                          /* window re-opened */
    /* duplicate ACK ignored */
    CHECK(sw_sender_process_ack(&s, 2U, 4U, &adv) == STATUS_OK && adv == 0U);
    /* ACK for something never sent (stale/invalid distance) ignored */
    CHECK(sw_sender_process_ack(&s, 9U, 4U, &adv) == STATUS_OK && adv == 0U);
    CHECK(s.base_abs == 2U);
    /* invalid ACK number */
    CHECK(sw_sender_process_ack(&s, SEQ_MODULUS, 4U, &adv) == STATUS_ERR_RANGE);
    CHECK(sw_sender_process_ack(NULL, 1U, 4U, &adv) == STATUS_ERR_NULL);
    CHECK(sw_sender_process_ack(&s, 1U, 4U, NULL) == STATUS_ERR_NULL);
}

static void test_sender_exhausted_and_init_errors(void)
{
    sw_sender_t s; packet_t *p = NULL; uint8_t pl[1] = {0U}; uint32_t adv;
    CHECK(sw_sender_init(&s, 4U, 1U, SRC, DST) == STATUS_OK);
    CHECK(sw_sender_next_packet(&s, pl, 1U, 0U, &p) == STATUS_OK);
    CHECK(sw_sender_process_ack(&s, 1U, 1U, &adv) == STATUS_OK && adv == 1U);
    CHECK(sw_sender_next_packet(&s, pl, 1U, 2U, &p) == STATUS_ERR_EMPTY);
    CHECK(sw_sender_init(NULL, 4U, 1U, SRC, DST) == STATUS_ERR_NULL);
    CHECK(sw_sender_init(&s, 0U, 1U, SRC, DST) == STATUS_ERR_RANGE);
    CHECK(sw_sender_init(&s, 16U, 1U, SRC, DST) == STATUS_ERR_RANGE);
    CHECK(sw_sender_init(&s, 4U, 0U, SRC, DST) == STATUS_ERR_RANGE);
    CHECK(sw_sender_init(&s, 4U, 1U, 0U, DST) == STATUS_ERR_RANGE);
    CHECK(sw_sender_next_packet(&s, pl, 1U, 0U, NULL) == STATUS_ERR_NULL);
    CHECK(sw_sender_outstanding(NULL) == 0U);
    CHECK(!sw_sender_can_send(NULL));
}

static void test_receiver_in_order_and_advance_and_wraparound(void)
{
    sw_receiver_t r; packet_t p; ack_t a; rx_result_t res; uint8_t i;
    uint8_t pl[1] = {7U};
    CHECK(sw_receiver_init(&r, 4U) == STATUS_OK);
    for (i = 0U; i < 40U; i++) {                            /* crosses wrap 2.5x */
        uint8_t seq = (uint8_t)(i % SEQ_MODULUS);
        CHECK(packet_init(&p, seq, SRC, DST, pl, 1U) == STATUS_OK);
        CHECK(sw_receiver_on_packet(&r, &p, &a, &res) == STATUS_OK);
        CHECK(res == RX_ACCEPTED);
        CHECK(a.ack_seq == (uint8_t)((i + 1U) % SEQ_MODULUS));
        CHECK(a.src == DST && a.dst == SRC);
    }
    CHECK(r.delivered == 40U);
    CHECK(r.expected_seq == (uint8_t)(40U % SEQ_MODULUS));
}

static void test_packet_checksum_and_corruption_detection(void)
{
    packet_t p; ack_t a; sw_receiver_t r; rx_result_t result;
    uint8_t payload[3] = {0x10U, 0x20U, 0x30U};
    CHECK(packet_init(&p, 0U, SRC, DST, payload, sizeof(payload)) == STATUS_OK);
    CHECK(packet_verify(&p));
    CHECK(packet_checksum(&p) == p.checksum);
    CHECK(sw_receiver_init(&r, 4U) == STATUS_OK);
    p.payload[1] ^= 0x01U; /* in-flight corruption: receiver must not deliver */
    CHECK(!packet_verify(&p));
    CHECK(sw_receiver_on_packet(&r, &p, &a, &result) == STATUS_ERR_FORMAT);
    CHECK(r.delivered == 0U && r.expected_seq == 0U);
    p.payload[1] ^= 0x01U;
    p.dst++; /* header corruption is covered too */
    CHECK(!packet_verify(&p));
    CHECK(packet_verify(NULL) == false);
    CHECK(packet_checksum(NULL) == 0U);
    CHECK(packet_init(&p, 0U, SRC, DST, payload, PAYLOAD_MAX + 1U) == STATUS_ERR_RANGE);
}

static void test_packet_checksum_header_fields(void)
{
    packet_t p; uint8_t payload[1] = {0xA5U};
    CHECK(packet_init(&p, 3U, SRC, DST, payload, sizeof(payload)) == STATUS_OK);
    CHECK(packet_verify(&p));
    p.src++; CHECK(!packet_verify(&p));
    p.src--; CHECK(packet_verify(&p));
    p.seq = 4U; CHECK(!packet_verify(&p));
    p.seq = 3U; CHECK(packet_verify(&p));
    p.payload_len = (uint8_t)(PAYLOAD_MAX + 1U); CHECK(!packet_verify(&p));
}

static void test_empty_payload_packet_integrity(void)
{
    packet_t p;
    CHECK(packet_init(&p, 15U, SRC, DST, NULL, 0U) == STATUS_OK);
    CHECK(p.payload_len == 0U && packet_verify(&p));
    CHECK(packet_checksum(&p) == p.checksum);
    p.checksum ^= 1U;
    CHECK(!packet_verify(&p));
}

static void test_receiver_duplicate_and_out_of_order(void)
{
    sw_receiver_t r; packet_t p; ack_t a; rx_result_t res; uint8_t pl[1] = {1U};
    CHECK(sw_receiver_init(&r, 4U) == STATUS_OK);
    (void)packet_init(&p, 0U, SRC, DST, pl, 1U);
    CHECK(sw_receiver_on_packet(&r, &p, &a, &res) == STATUS_OK && res == RX_ACCEPTED);
    /* same packet again -> duplicate, window does not move, ACK repeated */
    CHECK(sw_receiver_on_packet(&r, &p, &a, &res) == STATUS_OK && res == RX_DUPLICATE);
    CHECK(r.expected_seq == 1U && r.delivered == 1U && a.ack_seq == 1U);
    /* gap: seq 3 while expecting 1 -> discarded (Go-Back-N) */
    (void)packet_init(&p, 3U, SRC, DST, pl, 1U);
    CHECK(sw_receiver_on_packet(&r, &p, &a, &res) == STATUS_OK && res == RX_OUT_OF_ORDER);
    CHECK(r.expected_seq == 1U && r.delivered == 1U && a.ack_seq == 1U);
    /* error paths */
    p.seq = SEQ_MODULUS;
    CHECK(sw_receiver_on_packet(&r, &p, &a, &res) == STATUS_ERR_RANGE);
    CHECK(sw_receiver_on_packet(NULL, &p, &a, &res) == STATUS_ERR_NULL);
    CHECK(sw_receiver_init(NULL, 4U) == STATUS_ERR_NULL);
    CHECK(sw_receiver_init(&r, 0U) == STATUS_ERR_RANGE);
}

static void test_timeout_and_retransmit_marking(void)
{
    sw_sender_t s; packet_t *p = NULL; uint8_t pl[1] = {1U};
    CHECK(sw_sender_init(&s, 3U, 5U, SRC, DST) == STATUS_OK);
    CHECK(!sw_sender_timed_out(&s, 100U, 5U));              /* nothing outstanding */
    CHECK(sw_sender_next_packet(&s, pl, 1U, 10U, &p) == STATUS_OK);
    CHECK(sw_sender_next_packet(&s, pl, 1U, 10U, &p) == STATUS_OK);
    CHECK(!sw_sender_timed_out(&s, 14U, 5U));
    CHECK(sw_sender_timed_out(&s, 15U, 5U));
    CHECK(!sw_sender_timed_out(&s, 5U, 5U));                /* clock before timer */
    CHECK(!sw_sender_timed_out(NULL, 15U, 5U));
    CHECK(sw_sender_mark_retransmit(&s, 0U, 2U, 15U, &p) == STATUS_OK);
    CHECK(p->retry_count == 1U && p->status == PKT_STATUS_RETRANSMITTED);
    CHECK(sw_sender_mark_retransmit(&s, 0U, 2U, 20U, &p) == STATUS_OK);
    CHECK(sw_sender_mark_retransmit(&s, 0U, 2U, 25U, &p) == STATUS_ERR_MAX_RETRIES);
    CHECK(sw_sender_mark_retransmit(&s, 2U, 2U, 25U, &p) == STATUS_ERR_RANGE);
    CHECK(sw_sender_mark_retransmit(NULL, 0U, 2U, 25U, &p) == STATUS_ERR_NULL);
}

static void test_packet_loss_recovery(void)
{
    sw_config_t c = cfg(4U, 12U); sw_stats_t st;
    c.data_loss_every = 3U;
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_OK);
    CHECK(st.delivered == 12U);
    CHECK(st.data_lost > 0U && st.retransmissions > 0U && st.timeouts > 0U);
    CHECK(st.data_tx == 12U + st.retransmissions);
}

static void test_ack_loss_and_duplicate_detection(void)
{
    sw_config_t c = cfg(1U, 6U); sw_stats_t st;               /* stop-and-wait style */
    c.ack_loss_every = 2U;
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_OK);
    CHECK(st.delivered == 6U);
    CHECK(st.acks_lost > 0U && st.retransmissions > 0U);
    CHECK(st.duplicates > 0U);                                /* resent data already delivered */
}

static void test_out_of_order_discarded_in_simulation(void)
{
    sw_config_t c = cfg(4U, 8U); sw_stats_t st;
    c.data_loss_every = 5U;
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_OK);
    CHECK(st.out_of_order > 0U);
    CHECK(st.delivered == 8U);
}

static void test_max_retransmission_limit(void)
{
    sw_config_t c = cfg(4U, 5U); sw_stats_t st;
    c.data_loss_every = 1U;                                   /* every data packet lost */
    c.max_retries = 3U;
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_ERR_MAX_RETRIES);
    CHECK(st.delivered == 0U);
    CHECK(st.timeouts == 4U);                                 /* 3 retries + the aborting timeout */
    CHECK(st.ticks < SW_MAX_TICKS);                           /* no endless loop */
    c = cfg(2U, 4U); c.ack_loss_every = 1U; c.max_retries = 2U;   /* all ACKs lost */
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_ERR_MAX_RETRIES);
}

static void test_sequence_wraparound_in_simulation(void)
{
    sw_config_t c = cfg(15U, 100U); sw_stats_t st;            /* many wraps, max window */
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_OK);
    CHECK(st.delivered == 100U && st.data_tx == 100U);
    c = cfg(15U, 100U); c.data_loss_every = 11U;
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_OK && st.delivered == 100U);
    c = cfg(1U, 33U);
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_OK && st.delivered == 33U);
}

static void test_random_loss_is_repeatable(void)
{
    sw_config_t c = cfg(5U, 50U); sw_stats_t a; sw_stats_t b; sw_stats_t d;
    c.data_loss_percent = 20U; c.ack_loss_percent = 10U; c.seed = 42U; c.max_retries = 20U;
    CHECK(sw_simulate(&c, SRC, DST, NULL, &a) == STATUS_OK);
    CHECK(sw_simulate(&c, SRC, DST, NULL, &b) == STATUS_OK);
    CHECK(a.data_tx == b.data_tx && a.data_lost == b.data_lost && a.ticks == b.ticks &&
          a.acks_lost == b.acks_lost && a.timeouts == b.timeouts);   /* same seed -> same run */
    CHECK(a.delivered == 50U && a.data_lost > 0U);
    c.seed = 0U;                                              /* seed 0 is remapped */
    CHECK(sw_simulate(&c, SRC, DST, NULL, &d) == STATUS_OK && d.delivered == 50U);
}

static void test_logging_and_stats_output(void)
{
    sw_config_t c = cfg(3U, 6U); sw_stats_t st; FILE *f = fopen("test_sw_log.tmp.txt", "w+");
    char buf[32768]; size_t n;                 /* every line now carries a timestamp */
    CHECK(f != NULL);
    if (f == NULL) { return; }
    c.data_loss_every = 4U; c.ack_loss_every = 5U;
    CHECK(sw_simulate(&c, SRC, DST, f, &st) == STATUS_OK);
    sw_print_stats(f, &st);
    sw_print_stats(NULL, &st);
    sw_print_stats(f, NULL);
    rewind(f);
    n = fread(buf, 1U, sizeof(buf) - 1U, f);
    buf[n] = '\0';
    CHECK(strstr(buf, "SEND") != NULL && strstr(buf, "LOSS") != NULL);
    CHECK(strstr(buf, "TIMEOUT") != NULL && strstr(buf, "retransmit") != NULL);
    CHECK(strstr(buf, "DONE") != NULL && strstr(buf, "Efficiency") != NULL);
    (void)fclose(f);
    (void)remove("test_sw_log.tmp.txt");
}

static void test_packet_and_queue_primitives(void)
{
    packet_t p; pkt_queue_t q; ack_queue_t aq; packet_t out; ack_t a; ack_t aout;
    uint8_t big[PAYLOAD_MAX + 1U]; uint8_t pl[2] = {1U, 2U}; uint32_t i;
    (void)memset(big, 1, sizeof(big));
    CHECK(packet_init(&p, 0U, SRC, DST, big, PAYLOAD_MAX + 1U) == STATUS_ERR_RANGE);
    CHECK(packet_init(&p, 0U, SRC, DST, big, PAYLOAD_MAX) == STATUS_OK);
    CHECK(packet_init(&p, SEQ_MODULUS, SRC, DST, pl, 2U) == STATUS_ERR_RANGE);
    CHECK(packet_init(NULL, 0U, SRC, DST, pl, 2U) == STATUS_ERR_NULL);
    CHECK(packet_init(&p, 0U, SRC, DST, NULL, 2U) == STATUS_ERR_NULL);
    CHECK(packet_init(&p, 0U, SRC, DST, NULL, 0U) == STATUS_OK && p.payload_len == 0U);
    CHECK(packet_init(&p, 0U, 0U, DST, pl, 2U) == STATUS_ERR_RANGE);
    CHECK(seq_distance(14U, 2U) == 4U && seq_distance(3U, 3U) == 0U);
    CHECK(seq_next(15U) == 0U && seq_next(4U) == 5U);

    pktq_init(&q); ackq_init(&aq);
    (void)packet_init(&p, 1U, SRC, DST, pl, 2U);
    a.ack_seq = 3U; a.src = DST; a.dst = SRC;
    CHECK(!pktq_pop_due(&q, 0U, &out));                       /* empty */
    CHECK(!ackq_pop_due(&aq, 0U, &aout));
    for (i = 0U; i < CHANNEL_CAP; i++) {                      /* wraps ring several times */
        CHECK(pktq_push(&q, &p, 5U) == STATUS_OK);
        CHECK(ackq_push(&aq, &a, 5U) == STATUS_OK);
    }
    CHECK(pktq_push(&q, &p, 5U) == STATUS_ERR_FULL);
    CHECK(ackq_push(&aq, &a, 5U) == STATUS_ERR_FULL);
    CHECK(!pktq_pop_due(&q, 4U, &out));                       /* not yet due */
    CHECK(!ackq_pop_due(&aq, 4U, &aout));
    for (i = 0U; i < CHANNEL_CAP; i++) {
        CHECK(pktq_pop_due(&q, 5U, &out) && out.seq == 1U);
        CHECK(ackq_pop_due(&aq, 5U, &aout) && aout.ack_seq == 3U);
    }
    CHECK(pktq_push(&q, &p, 6U) == STATUS_OK && pktq_pop_due(&q, 6U, &out));
    CHECK(ackq_push(&aq, &a, 6U) == STATUS_OK && ackq_pop_due(&aq, 6U, &aout));
    CHECK(pktq_push(NULL, &p, 0U) == STATUS_ERR_NULL && pktq_push(&q, NULL, 0U) == STATUS_ERR_NULL);
    CHECK(ackq_push(NULL, &a, 0U) == STATUS_ERR_NULL && ackq_push(&aq, NULL, 0U) == STATUS_ERR_NULL);
    CHECK(!pktq_pop_due(NULL, 0U, &out) && !ackq_pop_due(NULL, 0U, &aout));
    pktq_init(NULL); ackq_init(NULL);
}

static void test_transmission_statistics_consistency(void)
{
    sw_config_t c = cfg(4U, 30U); sw_stats_t st;
    c.data_loss_every = 7U; c.ack_loss_every = 9U;
    CHECK(sw_simulate(&c, SRC, DST, NULL, &st) == STATUS_OK);
    CHECK(st.data_tx == st.data_received + st.data_lost);      /* every tx lands or is lost */
    CHECK(st.acks_sent == st.data_received);
    CHECK(st.acks_received + st.acks_lost == st.acks_sent);
    CHECK(st.delivered == st.packets_requested);
}

int main(void)
{
    RUN_TEST(test_config_validation);
    RUN_TEST(test_invalid_packet_count_and_window_in_simulation);
    RUN_TEST(test_fewer_than_window);
    RUN_TEST(test_exactly_window);
    RUN_TEST(test_more_than_window_no_loss);
    RUN_TEST(test_flow_control_sender_window);
    RUN_TEST(test_sender_exhausted_and_init_errors);
    RUN_TEST(test_receiver_in_order_and_advance_and_wraparound);
    RUN_TEST(test_receiver_duplicate_and_out_of_order);
    RUN_TEST(test_packet_checksum_and_corruption_detection);
    RUN_TEST(test_packet_checksum_header_fields);
    RUN_TEST(test_empty_payload_packet_integrity);
    RUN_TEST(test_timeout_and_retransmit_marking);
    RUN_TEST(test_packet_loss_recovery);
    RUN_TEST(test_ack_loss_and_duplicate_detection);
    RUN_TEST(test_out_of_order_discarded_in_simulation);
    RUN_TEST(test_max_retransmission_limit);
    RUN_TEST(test_sequence_wraparound_in_simulation);
    RUN_TEST(test_random_loss_is_repeatable);
    RUN_TEST(test_logging_and_stats_output);
    RUN_TEST(test_packet_and_queue_primitives);
    RUN_TEST(test_transmission_statistics_consistency);
    return TEST_SUMMARY();
}
