/* test_logger.c - timestamp / logging tests (48 test cases). */
#include <stdlib.h>
#include <string.h>
#include "test_framework.h"
#include "logger.h"
#include "sliding_window.h"

#define LOG_TMP "test_logger_a.tmp.txt"
#define LOG_TMP2 "test_logger_b.tmp.txt"

static uint64_t g_fake_ms = 0U;
static uint64_t fake_clock(void) { return g_fake_ms; }

/* true if text starts with "YYYY-MM-DD HH:MM:SS.mmm" */
static bool is_ts(const char *t)
{
    static const char pat[] = "dddd-dd-dd dd:dd:dd.ddd";
    size_t i;
    for (i = 0U; i < (sizeof(pat) - 1U); i++) {
        if (pat[i] == 'd') {
            if ((t[i] < '0') || (t[i] > '9')) { return false; }
        } else if (t[i] != pat[i]) {
            return false;
        }
    }
    return true;
}

static size_t slurp(FILE *f, char *buf, size_t cap)
{
    size_t n;
    (void)fflush(f);
    rewind(f);
    n = fread(buf, 1U, cap - 1U, f);
    buf[n] = '\0';
    return n;
}

static size_t count_char(const char *s, char c)
{
    size_t n = 0U;
    while (*s != '\0') { if (*s == c) { n++; } s++; }
    return n;
}

/* ---- timestamp formatting ------------------------------------------------ */
static void test_ts_epoch_zero_utc(void)
{
    char b[LOGGER_TS_LEN];
    CHECK(logger_format_time(0U, true, b, sizeof(b)) == STATUS_OK);
    CHECK(strcmp(b, "1970-01-01 00:00:00.000") == 0);
}
static void test_ts_known_date_2001(void)
{
    char b[LOGGER_TS_LEN];
    CHECK(logger_format_time(1000000000000ULL, true, b, sizeof(b)) == STATUS_OK);
    CHECK(strcmp(b, "2001-09-09 01:46:40.000") == 0);
}
static void test_ts_millisecond_zero_padding(void)
{
    char b[LOGGER_TS_LEN];
    CHECK(logger_format_time(1000000000007ULL, true, b, sizeof(b)) == STATUS_OK);
    CHECK(strcmp(b, "2001-09-09 01:46:40.007") == 0);
}
static void test_ts_millisecond_999(void)
{
    char b[LOGGER_TS_LEN];
    CHECK(logger_format_time(999U, true, b, sizeof(b)) == STATUS_OK);
    CHECK(strcmp(b, "1970-01-01 00:00:00.999") == 0);
}
static void test_ts_leap_day(void)
{
    char b[LOGGER_TS_LEN];
    CHECK(logger_format_time(951782400000ULL, true, b, sizeof(b)) == STATUS_OK);
    CHECK(strcmp(b, "2000-02-29 00:00:00.000") == 0);
}
static void test_ts_beyond_2038(void)
{
    char b[LOGGER_TS_LEN];
    CHECK(logger_format_time(2147483648000ULL, true, b, sizeof(b)) == STATUS_OK);
    CHECK(strcmp(b, "2038-01-19 03:14:08.000") == 0);
}
static void test_ts_null_buffer(void)
{
    CHECK(logger_format_time(0U, true, NULL, 32U) == STATUS_ERR_NULL);
    CHECK(logger_timestamp(NULL, 32U) == STATUS_ERR_NULL);
}
static void test_ts_capacity_too_small(void)
{
    char b[LOGGER_TS_LEN];
    CHECK(logger_format_time(0U, true, b, LOGGER_TS_LEN - 1U) == STATUS_ERR_RANGE);
    CHECK(logger_format_time(0U, true, b, 0U) == STATUS_ERR_RANGE);
}
static void test_ts_capacity_exact(void)
{
    char b[LOGGER_TS_LEN];
    CHECK(logger_format_time(5U, true, b, LOGGER_TS_LEN) == STATUS_OK);
    CHECK(strlen(b) == 23U);
}
static void test_ts_ist_exact(void)
{
    char b[LOGGER_TS_LEN];
    CHECK(logger_format_time(0U, false, b, sizeof(b)) == STATUS_OK);
    CHECK(strcmp(b, "1970-01-01 05:30:00.000") == 0);
    CHECK(logger_format_time(1000000000000ULL, false, b, sizeof(b)) == STATUS_OK);
    CHECK(strcmp(b, "2001-09-09 07:16:40.000") == 0);   /* 01:46:40 UTC + 5:30 */
    CHECK(logger_format_time(86399000ULL - 19800000ULL + 1000ULL, false, b, sizeof(b)) == STATUS_OK);
    CHECK(strncmp(b, "1970-01-02 00:00:00", 19U) == 0); /* date rolls over in IST */
}
static void test_ts_local_pattern(void)
{
    char b[LOGGER_TS_LEN];
    CHECK(logger_format_time(1000000000000ULL, false, b, sizeof(b)) == STATUS_OK);
    CHECK(is_ts(b));
}
static void test_ts_now_pattern(void)
{
    char b[LOGGER_TS_LEN];
    CHECK(logger_timestamp(b, sizeof(b)) == STATUS_OK);
    CHECK(is_ts(b) && strlen(b) == 23U);
}
static void test_now_ms_is_plausible(void)
{
    uint64_t t = logger_now_ms();
    CHECK(t > 1600000000000ULL);               /* after Sep 2020 */
    CHECK(t < 4102444800000ULL);               /* before year 2100 */
}
static void test_now_ms_two_reads_close(void)
{
    uint64_t a = logger_now_ms();
    uint64_t b = logger_now_ms();
    CHECK(((a > b) ? (a - b) : (b - a)) < 5000U);
}

/* ---- level names / init ---------------------------------------------------- */
static void test_level_names(void)
{
    CHECK(strcmp(logger_level_name(LOG_DEBUG), "DEBUG") == 0);
    CHECK(strcmp(logger_level_name(LOG_INFO), "INFO ") == 0);
    CHECK(strcmp(logger_level_name(LOG_WARN), "WARN ") == 0);
    CHECK(strcmp(logger_level_name(LOG_ERROR), "ERROR") == 0);
}
static void test_level_name_unknown(void)
{
    CHECK(strcmp(logger_level_name((log_level_t)99), "UNKNOWN") == 0);
}
static void test_init_null_logger(void)
{
    CHECK(logger_init(NULL, NULL, NULL, LOG_INFO) == STATUS_ERR_NULL);
}
static void test_init_invalid_level(void)
{
    logger_t l;
    CHECK(logger_init(&l, NULL, NULL, (log_level_t)7) == STATUS_ERR_RANGE);
    CHECK(logger_init(&l, NULL, NULL, (log_level_t)-1) == STATUS_ERR_RANGE);
}
static void test_init_defaults(void)
{
    logger_t l;
    CHECK(logger_init(&l, NULL, NULL, LOG_WARN) == STATUS_OK);
    CHECK(l.clock != NULL && l.lines == 0U && !l.owns_file && !l.use_utc);
    CHECK(l.min_level == LOG_WARN && l.file == NULL && l.console == NULL);
}

/* ---- log record content ------------------------------------------------------ */
static void test_log_exact_line(void)
{
    logger_t l; FILE *f = fopen(LOG_TMP, "w+"); char b[512];
    CHECK(f != NULL);
    if (f == NULL) { return; }
    g_fake_ms = 1234U;
    CHECK(logger_init(&l, f, NULL, LOG_DEBUG) == STATUS_OK);
    logger_set_clock(&l, fake_clock); logger_set_utc(&l, true);
    CHECK(logger_log(&l, LOG_INFO, "main", "hello %u", 42U) == STATUS_OK);
    (void)slurp(f, b, sizeof(b));
    CHECK(strcmp(b, "1970-01-01 00:00:01.234 | INFO  | main            | hello 42\n") == 0);
    (void)fclose(f); (void)remove(LOG_TMP);
}
static void test_log_level_filter_drops_lower(void)
{
    logger_t l; FILE *f = fopen(LOG_TMP, "w+"); char b[512];
    CHECK(f != NULL);
    if (f == NULL) { return; }
    CHECK(logger_init(&l, f, NULL, LOG_WARN) == STATUS_OK);
    CHECK(logger_log(&l, LOG_INFO, "m", "dropped") == STATUS_OK);
    CHECK(logger_log(&l, LOG_DEBUG, "m", "dropped") == STATUS_OK);
    CHECK(logger_log(&l, LOG_WARN, "m", "kept-w") == STATUS_OK);
    CHECK(logger_log(&l, LOG_ERROR, "m", "kept-e") == STATUS_OK);
    (void)slurp(f, b, sizeof(b));
    CHECK(strstr(b, "dropped") == NULL && strstr(b, "kept-w") != NULL && strstr(b, "kept-e") != NULL);
    CHECK(l.lines == 2U);
    (void)fclose(f); (void)remove(LOG_TMP);
}
static void test_log_debug_level_writes_all(void)
{
    logger_t l; FILE *f = fopen(LOG_TMP, "w+"); char b[512];
    CHECK(f != NULL);
    if (f == NULL) { return; }
    CHECK(logger_init(&l, f, NULL, LOG_DEBUG) == STATUS_OK);
    CHECK(logger_log(&l, LOG_DEBUG, "m", "d") == STATUS_OK);
    CHECK(logger_log(&l, LOG_ERROR, "m", "e") == STATUS_OK);
    (void)slurp(f, b, sizeof(b));
    CHECK(count_char(b, '\n') == 2U && l.lines == 2U);
    (void)fclose(f); (void)remove(LOG_TMP);
}
static void test_log_null_arguments(void)
{
    logger_t l;
    CHECK(logger_init(&l, NULL, NULL, LOG_INFO) == STATUS_OK);
    CHECK(logger_log(NULL, LOG_INFO, "m", "x") == STATUS_ERR_NULL);
    CHECK(logger_log(&l, LOG_INFO, NULL, "x") == STATUS_ERR_NULL);
    CHECK(logger_log(&l, LOG_INFO, "m", NULL) == STATUS_ERR_NULL);
}
static void test_log_invalid_level(void)
{
    logger_t l;
    CHECK(logger_init(&l, NULL, NULL, LOG_INFO) == STATUS_OK);
    CHECK(logger_log(&l, (log_level_t)9, "m", "x") == STATUS_ERR_RANGE);
    CHECK(logger_log(&l, (log_level_t)-3, "m", "x") == STATUS_ERR_RANGE);
}
static void test_log_newlines_are_sanitised(void)
{
    logger_t l; FILE *f = fopen(LOG_TMP, "w+"); char b[512];
    CHECK(f != NULL);
    if (f == NULL) { return; }
    CHECK(logger_init(&l, f, NULL, LOG_INFO) == STATUS_OK);
    CHECK(logger_log(&l, LOG_INFO, "m", "a\nFAKE | ERROR | x\r\nb") == STATUS_OK);
    (void)slurp(f, b, sizeof(b));
    CHECK(count_char(b, '\n') == 1U && count_char(b, '\r') == 0U);   /* log forging prevented */
    (void)fclose(f); (void)remove(LOG_TMP);
}
static void test_log_long_message_truncated(void)
{
    logger_t l; FILE *f = fopen(LOG_TMP, "w+"); char b[2048]; char big[1000];
    CHECK(f != NULL);
    if (f == NULL) { return; }
    (void)memset(big, 'x', sizeof(big)); big[sizeof(big) - 1U] = '\0';
    CHECK(logger_init(&l, f, NULL, LOG_INFO) == STATUS_OK);
    CHECK(logger_log(&l, LOG_INFO, "m", "%s", big) == STATUS_OK);
    CHECK(slurp(f, b, sizeof(b)) < (LOGGER_MESSAGE_MAX + LOGGER_TS_LEN + 40U));
    CHECK(count_char(b, '\n') == 1U);
    (void)fclose(f); (void)remove(LOG_TMP);
}
static void test_log_module_truncated_to_15(void)
{
    logger_t l; FILE *f = fopen(LOG_TMP, "w+"); char b[512];
    CHECK(f != NULL);
    if (f == NULL) { return; }
    CHECK(logger_init(&l, f, NULL, LOG_INFO) == STATUS_OK);
    CHECK(logger_log(&l, LOG_INFO, "abcdefghijklmnopqrstuvwxyz", "x") == STATUS_OK);
    (void)slurp(f, b, sizeof(b));
    CHECK(strstr(b, "| abcdefghijklmno | x") != NULL);
    (void)fclose(f); (void)remove(LOG_TMP);
}
static void test_log_module_padded(void)
{
    logger_t l; FILE *f = fopen(LOG_TMP, "w+"); char b[512];
    CHECK(f != NULL);
    if (f == NULL) { return; }
    CHECK(logger_init(&l, f, NULL, LOG_INFO) == STATUS_OK);
    CHECK(logger_log(&l, LOG_INFO, "ab", "x") == STATUS_OK);
    (void)slurp(f, b, sizeof(b));
    CHECK(strstr(b, "| ab              | x") != NULL);
    (void)fclose(f); (void)remove(LOG_TMP);
}
static void test_log_file_and_console_both_written(void)
{
    logger_t l; FILE *f = fopen(LOG_TMP, "w+"); FILE *c = fopen(LOG_TMP2, "w+"); char b1[512]; char b2[512];
    CHECK(f != NULL && c != NULL);
    if ((f == NULL) || (c == NULL)) { if (f != NULL) { (void)fclose(f); } if (c != NULL) { (void)fclose(c); } return; }
    CHECK(logger_init(&l, f, c, LOG_INFO) == STATUS_OK);
    CHECK(logger_log(&l, LOG_WARN, "m", "both") == STATUS_OK);
    (void)slurp(f, b1, sizeof(b1)); (void)slurp(c, b2, sizeof(b2));
    CHECK(strcmp(b1, b2) == 0 && strstr(b1, "both") != NULL);
    (void)fclose(f); (void)fclose(c); (void)remove(LOG_TMP); (void)remove(LOG_TMP2);
}
static void test_log_console_only(void)
{
    logger_t l; FILE *c = fopen(LOG_TMP2, "w+"); char b[512];
    CHECK(c != NULL);
    if (c == NULL) { return; }
    CHECK(logger_init(&l, NULL, c, LOG_INFO) == STATUS_OK);
    CHECK(logger_log(&l, LOG_INFO, "m", "only console") == STATUS_OK);
    (void)slurp(c, b, sizeof(b));
    CHECK(strstr(b, "only console") != NULL && l.lines == 1U);
    (void)fclose(c); (void)remove(LOG_TMP2);
}
static void test_log_no_sink_is_noop(void)
{
    logger_t l;
    CHECK(logger_init(&l, NULL, NULL, LOG_DEBUG) == STATUS_OK);
    CHECK(logger_log(&l, LOG_ERROR, "m", "nobody listens") == STATUS_OK);
    CHECK(l.lines == 0U);
}
static void test_log_line_counter(void)
{
    logger_t l; FILE *f = fopen(LOG_TMP, "w+"); uint32_t i;
    CHECK(f != NULL);
    if (f == NULL) { return; }
    CHECK(logger_init(&l, f, NULL, LOG_INFO) == STATUS_OK);
    for (i = 0U; i < 25U; i++) { CHECK(logger_log(&l, LOG_INFO, "m", "n=%u", (unsigned)i) == STATUS_OK); }
    CHECK(l.lines == 25U);
    (void)fclose(f); (void)remove(LOG_TMP);
}
static void test_log_string_and_number_formats(void)
{
    logger_t l; FILE *f = fopen(LOG_TMP, "w+"); char b[512];
    CHECK(f != NULL);
    if (f == NULL) { return; }
    CHECK(logger_init(&l, f, NULL, LOG_INFO) == STATUS_OK);
    CHECK(logger_log(&l, LOG_INFO, "m", "%s|%05u|%-3u|", "str", 42U, 7U) == STATUS_OK);
    (void)slurp(f, b, sizeof(b));
    CHECK(strstr(b, "str|00042|7  |") != NULL);
    (void)fclose(f); (void)remove(LOG_TMP);
}
static void test_log_timestamp_prefix_matches_pattern(void)
{
    logger_t l; FILE *f = fopen(LOG_TMP, "w+"); char b[512];
    CHECK(f != NULL);
    if (f == NULL) { return; }
    CHECK(logger_init(&l, f, NULL, LOG_INFO) == STATUS_OK);   /* real clock */
    CHECK(logger_log(&l, LOG_INFO, "m", "x") == STATUS_OK);
    (void)slurp(f, b, sizeof(b));
    CHECK(is_ts(b) && b[23] == ' ' && b[24] == '|');
    (void)fclose(f); (void)remove(LOG_TMP);
}

/* ---- clock / open / close -------------------------------------------------- */
static void test_set_clock_null_restores_default(void)
{
    logger_t l;
    CHECK(logger_init(&l, NULL, NULL, LOG_INFO) == STATUS_OK);
    logger_set_clock(&l, fake_clock);
    CHECK(l.clock == fake_clock);
    logger_set_clock(&l, NULL);
    CHECK(l.clock == logger_now_ms);
    logger_set_clock(NULL, fake_clock);            /* must not crash */
    logger_set_utc(NULL, true);
}
static void test_set_utc_changes_output(void)
{
    logger_t l; FILE *f = fopen(LOG_TMP, "w+"); char b[512];
    CHECK(f != NULL);
    if (f == NULL) { return; }
    g_fake_ms = 3600000U;
    CHECK(logger_init(&l, f, NULL, LOG_INFO) == STATUS_OK);
    logger_set_clock(&l, fake_clock); logger_set_utc(&l, true);
    CHECK(l.use_utc);
    CHECK(logger_log(&l, LOG_INFO, "m", "x") == STATUS_OK);
    (void)slurp(f, b, sizeof(b));
    CHECK(strncmp(b, "1970-01-01 01:00:00.000", 23U) == 0);
    (void)fclose(f); (void)remove(LOG_TMP);
}
static void test_open_appends_across_sessions(void)
{
    logger_t l; FILE *f; char b[512];
    (void)remove(LOG_TMP);
    CHECK(logger_open(&l, LOG_TMP, NULL, LOG_INFO) == STATUS_OK && l.owns_file);
    CHECK(logger_log(&l, LOG_INFO, "m", "first") == STATUS_OK);
    logger_close(&l);
    CHECK(logger_open(&l, LOG_TMP, NULL, LOG_INFO) == STATUS_OK);
    CHECK(logger_log(&l, LOG_INFO, "m", "second") == STATUS_OK);
    logger_close(&l);
    f = fopen(LOG_TMP, "r");
    CHECK(f != NULL);
    if (f != NULL) {
        (void)slurp(f, b, sizeof(b));
        CHECK(strstr(b, "first") != NULL && strstr(b, "second") != NULL && count_char(b, '\n') == 2U);
        (void)fclose(f);
    }
    (void)remove(LOG_TMP);
}
static void test_open_bad_arguments(void)
{
    logger_t l;
    CHECK(logger_open(NULL, LOG_TMP, NULL, LOG_INFO) == STATUS_ERR_NULL);
    CHECK(logger_open(&l, NULL, NULL, LOG_INFO) == STATUS_ERR_NULL);
    CHECK(logger_open(&l, "no_such_dir_xyz/log.txt", NULL, LOG_INFO) == STATUS_ERR_IO);
}
static void test_open_invalid_level_closes_file(void)
{
    logger_t l;
    CHECK(logger_open(&l, LOG_TMP, NULL, (log_level_t)42) == STATUS_ERR_RANGE);
    (void)remove(LOG_TMP);
}
static void test_close_is_idempotent(void)
{
    logger_t l;
    (void)remove(LOG_TMP);
    CHECK(logger_open(&l, LOG_TMP, NULL, LOG_INFO) == STATUS_OK);
    logger_close(&l);
    CHECK(l.file == NULL && !l.owns_file);
    logger_close(&l);                              /* second close is harmless */
    logger_close(NULL);
    CHECK(logger_log(&l, LOG_INFO, "m", "after close") == STATUS_OK && l.lines == 0U);
    (void)remove(LOG_TMP);
}
static void test_close_keeps_foreign_file_open(void)
{
    logger_t l; FILE *f = fopen(LOG_TMP, "w+");
    CHECK(f != NULL);
    if (f == NULL) { return; }
    CHECK(logger_init(&l, f, NULL, LOG_INFO) == STATUS_OK);
    logger_close(&l);
    CHECK(fputs("still open\n", f) >= 0);          /* not owned -> not closed */
    (void)fclose(f); (void)remove(LOG_TMP);
}

/* ---- timestamps inside the simulation ------------------------------------------ */
static sw_config_t quick_cfg(void)
{
    sw_config_t c;
    (void)sw_config_default(&c);
    c.packet_count = 8U; c.window_size = 3U; c.data_loss_every = 4U; c.ack_loss_every = 0U;
    return c;
}
static void test_sim_log_lines_start_with_timestamp(void)
{
    sw_config_t c = quick_cfg(); sw_stats_t st; FILE *f = fopen(LOG_TMP, "w+"); char b[8192];
    CHECK(f != NULL);
    if (f == NULL) { return; }
    CHECK(sw_simulate(&c, 101U, 202U, f, &st) == STATUS_OK);
    (void)slurp(f, b, sizeof(b));
    CHECK(b[0] == '[' && is_ts(&b[1]) && b[24] == ']');
    (void)fclose(f); (void)remove(LOG_TMP);
}
static void test_sim_every_log_line_has_timestamp(void)
{
    sw_config_t c = quick_cfg(); sw_stats_t st; FILE *f = fopen(LOG_TMP, "w+"); char b[8192]; char *line; size_t lines = 0U; bool all = true;
    CHECK(f != NULL);
    if (f == NULL) { return; }
    CHECK(sw_simulate(&c, 101U, 202U, f, &st) == STATUS_OK);
    (void)slurp(f, b, sizeof(b));
    line = b;
    while (*line != '\0') {
        char *nl = strchr(line, '\n');
        if ((line[0] != '[') || !is_ts(&line[1])) { all = false; }
        lines++;
        if (nl == NULL) { break; }
        line = nl + 1;
    }
    CHECK(all && lines > 8U);
    (void)fclose(f); (void)remove(LOG_TMP);
}
static void test_sim_log_has_start_event(void)
{
    sw_config_t c = quick_cfg(); sw_stats_t st; FILE *f = fopen(LOG_TMP, "w+"); char b[8192];
    CHECK(f != NULL);
    if (f == NULL) { return; }
    CHECK(sw_simulate(&c, 101U, 202U, f, &st) == STATUS_OK);
    (void)slurp(f, b, sizeof(b));
    CHECK(strstr(b, "START simulation: stn 101 -> 202") != NULL);
    CHECK(strstr(b, "DONE  all 8 packet(s)") != NULL);
    (void)fclose(f); (void)remove(LOG_TMP);
}
static void test_sim_stats_have_start_and_finish_stamps(void)
{
    sw_config_t c = quick_cfg(); sw_stats_t st;
    CHECK(sw_simulate(&c, 101U, 202U, NULL, &st) == STATUS_OK);
    CHECK(is_ts(st.started_at) && is_ts(st.finished_at));
    CHECK(strlen(st.started_at) == 23U && strlen(st.finished_at) == 23U);
}
static void test_sim_stats_stamps_set_even_when_it_fails(void)
{
    sw_config_t c = quick_cfg(); sw_stats_t st;
    c.data_loss_every = 1U; c.max_retries = 2U;
    CHECK(sw_simulate(&c, 101U, 202U, NULL, &st) == STATUS_ERR_MAX_RETRIES);
    CHECK(is_ts(st.started_at) && is_ts(st.finished_at));
}
static void test_sim_stats_stamps_empty_on_invalid_config(void)
{
    sw_config_t c = quick_cfg(); sw_stats_t st;
    c.window_size = 0U;
    CHECK(sw_simulate(&c, 101U, 202U, NULL, &st) == STATUS_ERR_RANGE);
    CHECK(st.started_at[0] == '\0' && st.finished_at[0] == '\0');
}
static void test_print_stats_shows_timestamps(void)
{
    sw_config_t c = quick_cfg(); sw_stats_t st; FILE *f = fopen(LOG_TMP, "w+"); char b[2048];
    CHECK(f != NULL);
    if (f == NULL) { return; }
    CHECK(sw_simulate(&c, 101U, 202U, NULL, &st) == STATUS_OK);
    sw_print_stats(f, &st);
    (void)slurp(f, b, sizeof(b));
    CHECK(strstr(b, "Started at") != NULL && strstr(b, "Finished at") != NULL);
    CHECK(strstr(b, st.started_at) != NULL && strstr(b, st.finished_at) != NULL);
    (void)fclose(f); (void)remove(LOG_TMP);
}
static void test_print_stats_without_run_hides_timestamps(void)
{
    sw_stats_t st; FILE *f = fopen(LOG_TMP, "w+"); char b[2048];
    CHECK(f != NULL);
    if (f == NULL) { return; }
    (void)memset(&st, 0, sizeof(st));
    sw_print_stats(f, &st);
    (void)slurp(f, b, sizeof(b));
    CHECK(strstr(b, "Started at") == NULL && strstr(b, "Packets requested") != NULL);
    (void)fclose(f); (void)remove(LOG_TMP);
}

int main(void)
{
    RUN_TEST(test_ts_epoch_zero_utc);
    RUN_TEST(test_ts_known_date_2001);
    RUN_TEST(test_ts_millisecond_zero_padding);
    RUN_TEST(test_ts_millisecond_999);
    RUN_TEST(test_ts_leap_day);
    RUN_TEST(test_ts_beyond_2038);
    RUN_TEST(test_ts_null_buffer);
    RUN_TEST(test_ts_capacity_too_small);
    RUN_TEST(test_ts_capacity_exact);
    RUN_TEST(test_ts_local_pattern);
    RUN_TEST(test_ts_ist_exact);
    RUN_TEST(test_ts_now_pattern);
    RUN_TEST(test_now_ms_is_plausible);
    RUN_TEST(test_now_ms_two_reads_close);
    RUN_TEST(test_level_names);
    RUN_TEST(test_level_name_unknown);
    RUN_TEST(test_init_null_logger);
    RUN_TEST(test_init_invalid_level);
    RUN_TEST(test_init_defaults);
    RUN_TEST(test_log_exact_line);
    RUN_TEST(test_log_level_filter_drops_lower);
    RUN_TEST(test_log_debug_level_writes_all);
    RUN_TEST(test_log_null_arguments);
    RUN_TEST(test_log_invalid_level);
    RUN_TEST(test_log_newlines_are_sanitised);
    RUN_TEST(test_log_long_message_truncated);
    RUN_TEST(test_log_module_truncated_to_15);
    RUN_TEST(test_log_module_padded);
    RUN_TEST(test_log_file_and_console_both_written);
    RUN_TEST(test_log_console_only);
    RUN_TEST(test_log_no_sink_is_noop);
    RUN_TEST(test_log_line_counter);
    RUN_TEST(test_log_string_and_number_formats);
    RUN_TEST(test_log_timestamp_prefix_matches_pattern);
    RUN_TEST(test_set_clock_null_restores_default);
    RUN_TEST(test_set_utc_changes_output);
    RUN_TEST(test_open_appends_across_sessions);
    RUN_TEST(test_open_bad_arguments);
    RUN_TEST(test_open_invalid_level_closes_file);
    RUN_TEST(test_close_is_idempotent);
    RUN_TEST(test_close_keeps_foreign_file_open);
    RUN_TEST(test_sim_log_lines_start_with_timestamp);
    RUN_TEST(test_sim_every_log_line_has_timestamp);
    RUN_TEST(test_sim_log_has_start_event);
    RUN_TEST(test_sim_stats_have_start_and_finish_stamps);
    RUN_TEST(test_sim_stats_stamps_set_even_when_it_fails);
    RUN_TEST(test_sim_stats_stamps_empty_on_invalid_config);
    RUN_TEST(test_print_stats_shows_timestamps);
    RUN_TEST(test_print_stats_without_run_hides_timestamps);
    return TEST_SUMMARY();
}
