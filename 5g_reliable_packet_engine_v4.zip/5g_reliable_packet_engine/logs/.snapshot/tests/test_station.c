/* test_station.c - station validation, input parsing, storage and functional tests. */
#include <stdlib.h>
#include <string.h>
#include "test_framework.h"
#include "bst.h"
#include "input.h"
#include "sliding_window.h"
#include "storage.h"

#define TMP_FILE "test_stations.tmp.txt"
#define TMP_IN   "test_input.tmp.txt"

static void write_file(const char *path, const char *content)
{
    FILE *f = fopen(path, "w");
    if (f != NULL) { (void)fputs(content, f); (void)fclose(f); }
}

static void test_station_validation(void)
{
    station_t s;
    char long_name[64];
    CHECK(station_init(&s, 1U, "Alpha-1_x.y", 10U, 100U, 1U, "gNodeB") == STATUS_OK);
    CHECK(s.id == 1U && strcmp(s.name, "Alpha-1_x.y") == 0 && s.distance_km == 10U);
    CHECK(station_init(NULL, 1U, "A", 1U, 100U, 1U, "B") == STATUS_ERR_NULL);
    CHECK(station_init(&s, 0U, "A", 1U, 100U, 1U, "B") == STATUS_ERR_RANGE);            /* id low  */
    CHECK(station_init(&s, STATION_ID_MAX + 1U, "A", 1U, 100U, 1U, "B") == STATUS_ERR_RANGE);
    CHECK(station_init(&s, STATION_ID_MAX, "A", 1U, 100U, 1U, "B") == STATUS_OK);        /* boundary */
    CHECK(station_init(&s, 1U, "", 1U, 100U, 1U, "B") == STATUS_ERR_FORMAT);             /* empty */
    CHECK(station_init(&s, 1U, NULL, 1U, 100U, 1U, "B") == STATUS_ERR_NULL);
    CHECK(station_init(&s, 1U, "A", 1U, 100U, 1U, NULL) == STATUS_ERR_NULL);
    CHECK(station_init(&s, 1U, "A|B", 1U, 100U, 1U, "B") == STATUS_ERR_FORMAT);          /* delimiter */
    CHECK(station_init(&s, 1U, "A\nB", 1U, 100U, 1U, "B") == STATUS_ERR_FORMAT);
    CHECK(station_init(&s, 1U, " A", 1U, 100U, 1U, "B") == STATUS_ERR_FORMAT);
    CHECK(station_init(&s, 1U, "A ", 1U, 100U, 1U, "B") == STATUS_ERR_FORMAT);
    CHECK(station_init(&s, 1U, "A", STATION_DISTANCE_MAX + 1U, 100U, 1U, "B") == STATUS_ERR_RANGE);
    CHECK(station_init(&s, 1U, "A", STATION_DISTANCE_MAX, 100U, 1U, "B") == STATUS_OK);
    (void)memset(long_name, 'a', sizeof(long_name)); long_name[63] = '\0';
    CHECK(station_init(&s, 1U, long_name, 1U, 100U, 1U, "B") == STATUS_ERR_RANGE);       /* too long */
    long_name[STATION_NAME_MAX - 1U] = '\0';                                   /* 31 chars */
    CHECK(station_init(&s, 1U, long_name, 1U, 100U, 1U, "B") == STATUS_OK);
    CHECK(station_init(&s, 1U, "A", 1U, 100U, 1U, "ThisTypeIsFarTooLong") == STATUS_ERR_RANGE);
    CHECK(station_validate(NULL) == STATUS_ERR_NULL);
    CHECK(station_validate_text(NULL, 8U) == STATUS_ERR_NULL);
    CHECK(station_validate_text("x", 1U) == STATUS_ERR_NULL);
    station_print(&s); station_print(NULL);
}

static void test_fare_and_platform_validation(void)
{
    station_t s;

    CHECK(station_init(&s, 1U, "A", 1U, 0U, STATION_PLATFORM_MIN, "B") == STATUS_OK);
    CHECK(s.fare == 0U && s.platform == STATION_PLATFORM_MIN);           /* lower bounds */
    CHECK(station_init(&s, 1U, "A", 1U, STATION_FARE_MAX, STATION_PLATFORM_MAX, "B") == STATUS_OK);
    CHECK(s.fare == STATION_FARE_MAX && s.platform == STATION_PLATFORM_MAX);
    CHECK(station_init(&s, 1U, "A", 1U, STATION_FARE_MAX + 1U, 1U, "B") == STATUS_ERR_RANGE);
    CHECK(station_init(&s, 1U, "A", 1U, 10U, 0U, "B") == STATUS_ERR_RANGE);
    CHECK(station_init(&s, 1U, "A", 1U, 10U, STATION_PLATFORM_MAX + 1U, "B") == STATUS_ERR_RANGE);
    CHECK(station_validate_numbers(1U, 10U, 1U) == STATUS_OK);
    CHECK(station_validate_numbers(STATION_DISTANCE_MAX + 1U, 10U, 1U) == STATUS_ERR_RANGE);
    CHECK(station_validate_numbers(1U, STATION_FARE_MAX + 1U, 1U) == STATUS_ERR_RANGE);
    CHECK(station_validate_numbers(1U, 10U, 0U) == STATUS_ERR_RANGE);
    /* a record edited behind the API is caught by station_validate */
    CHECK(station_init(&s, 1U, "A", 1U, 10U, 1U, "B") == STATUS_OK);
    s.fare = STATION_FARE_MAX + 1U;
    CHECK(station_validate(&s) == STATUS_ERR_RANGE);
    s.fare = 10U;
    s.platform = 0U;
    CHECK(station_validate(&s) == STATUS_ERR_RANGE);
}

static void test_endpoint_validation(void)
{
    bst_t t; station_t a; station_t b; station_id_t bad = 7U;
    bst_init(&t);
    (void)station_init(&a, 100U, "A", 1U, 100U, 1U, "Core");
    (void)station_init(&b, 200U, "B", 2U, 100U, 1U, "Core");
    (void)bst_insert(&t, &a); (void)bst_insert(&t, &b);
    CHECK(station_validate_endpoints(&t, 100U, 200U, &bad) == STATUS_OK && bad == 0U);
    CHECK(station_validate_endpoints(&t, 100U, 100U, &bad) == STATUS_ERR_SAME_ENDPOINT);
    CHECK(station_validate_endpoints(&t, 999U, 200U, &bad) == STATUS_ERR_NOT_FOUND && bad == 999U);
    CHECK(station_validate_endpoints(&t, 100U, 998U, &bad) == STATUS_ERR_NOT_FOUND && bad == 998U);
    CHECK(station_validate_endpoints(&t, 0U, 200U, &bad) == STATUS_ERR_RANGE);
    CHECK(station_validate_endpoints(&t, 100U, 0U, NULL) == STATUS_ERR_RANGE);
    CHECK(station_validate_endpoints(NULL, 1U, 2U, &bad) == STATUS_ERR_NULL);
    bst_destroy(&t);
    bst_init(&t);                                              /* empty tree is safe */
    CHECK(station_validate_endpoints(&t, 1U, 2U, &bad) == STATUS_ERR_NOT_FOUND);
}

static void test_parse_u32(void)
{
    uint32_t v = 0U;
    CHECK(input_parse_u32("42", 0U, 100U, &v) == STATUS_OK && v == 42U);
    CHECK(input_parse_u32("  42 \t", 0U, 100U, &v) == STATUS_OK && v == 42U);
    CHECK(input_parse_u32("", 0U, 100U, &v) == STATUS_ERR_FORMAT);              /* empty */
    CHECK(input_parse_u32("   ", 0U, 100U, &v) == STATUS_ERR_FORMAT);
    CHECK(input_parse_u32("-5", 0U, 100U, &v) == STATUS_ERR_FORMAT);            /* negative */
    CHECK(input_parse_u32("+5", 0U, 100U, &v) == STATUS_ERR_FORMAT);
    CHECK(input_parse_u32("abc", 0U, 100U, &v) == STATUS_ERR_FORMAT);           /* text */
    CHECK(input_parse_u32("12abc", 0U, 100U, &v) == STATUS_ERR_FORMAT);         /* trailing */
    CHECK(input_parse_u32("1 2", 0U, 100U, &v) == STATUS_ERR_FORMAT);
    CHECK(input_parse_u32("3.5", 0U, 100U, &v) == STATUS_ERR_FORMAT);
    CHECK(input_parse_u32("101", 0U, 100U, &v) == STATUS_ERR_RANGE);            /* high */
    CHECK(input_parse_u32("4", 5U, 100U, &v) == STATUS_ERR_RANGE);              /* low */
    CHECK(input_parse_u32("99999999999999999999", 0U, 100U, &v) == STATUS_ERR_RANGE); /* overflow */
    CHECK(input_parse_u32("4294967295", 0U, UINT32_MAX, &v) == STATUS_OK && v == UINT32_MAX);
    CHECK(input_parse_u32("4294967296", 0U, UINT32_MAX, &v) == STATUS_ERR_RANGE);
    CHECK(input_parse_u32(NULL, 0U, 1U, &v) == STATUS_ERR_NULL);
    CHECK(input_parse_u32("1", 0U, 1U, NULL) == STATUS_ERR_NULL);
}

static void test_read_line(void)
{
    char buf[8]; FILE *f;
    write_file(TMP_IN, "abc\r\n1234567\n12345678901\nlast");
    f = fopen(TMP_IN, "r");
    CHECK(f != NULL);
    if (f == NULL) { return; }
    CHECK(input_read_line(f, buf, sizeof(buf)) == STATUS_OK && strcmp(buf, "abc") == 0);   /* CRLF stripped */
    CHECK(input_read_line(f, buf, sizeof(buf)) == STATUS_OK && strcmp(buf, "1234567") == 0); /* exact fit */
    CHECK(input_read_line(f, buf, sizeof(buf)) == STATUS_ERR_RANGE);                         /* too long */
    CHECK(input_read_line(f, buf, sizeof(buf)) == STATUS_OK && strcmp(buf, "last") == 0);    /* no newline */
    CHECK(input_read_line(f, buf, sizeof(buf)) == STATUS_ERR_IO);                            /* EOF */
    CHECK(input_read_line(NULL, buf, sizeof(buf)) == STATUS_ERR_NULL);
    CHECK(input_read_line(f, NULL, 8U) == STATUS_ERR_NULL);
    CHECK(input_read_line(f, buf, 1U) == STATUS_ERR_NULL);
    (void)fclose(f);
    write_file(TMP_IN, "1234567");                                                           /* exact fit + EOF */
    f = fopen(TMP_IN, "r");
    if (f != NULL) {
        CHECK(input_read_line(f, buf, sizeof(buf)) == STATUS_OK && strcmp(buf, "1234567") == 0);
        (void)fclose(f);
    }
    (void)remove(TMP_IN);
}

static status_t name_ok(const char *t) { return station_validate_text(t, STATION_NAME_MAX); }

static void test_prompts(void)
{
    FILE *in; FILE *out; uint32_t v = 0U; char text[64];
    out = fopen(TMP_FILE, "w");
    CHECK(out != NULL);
    if (out == NULL) { return; }
    write_file(TMP_IN, "abc\n-3\n77\n");                          /* 2 bad then good */
    in = fopen(TMP_IN, "r");
    CHECK(in != NULL);
    if (in != NULL) {
        CHECK(input_prompt_u32(in, out, "n", 1U, 100U, &v) == STATUS_OK && v == 77U);
        (void)fclose(in);
    }
    write_file(TMP_IN, "x\ny\nz\n5\n");                         /* 3 bad attempts exhausted */
    in = fopen(TMP_IN, "r");
    if (in != NULL) {
        CHECK(input_prompt_u32(in, out, "n", 1U, 4U, &v) == STATUS_ERR_RANGE);
        (void)fclose(in);
    }
    write_file(TMP_IN, "");                                     /* EOF */
    in = fopen(TMP_IN, "r");
    if (in != NULL) {
        CHECK(input_prompt_u32(in, out, "n", 1U, 4U, &v) == STATUS_ERR_IO);
        CHECK(input_prompt_text(in, out, "t", text, sizeof(text), name_ok) == STATUS_ERR_IO);
        (void)fclose(in);
    }
    write_file(TMP_IN, "bad|name\nGood Name\n");
    in = fopen(TMP_IN, "r");
    if (in != NULL) {
        CHECK(input_prompt_text(in, out, "t", text, sizeof(text), name_ok) == STATUS_OK);
        CHECK(strcmp(text, "Good Name") == 0);
        CHECK(input_prompt_u32(NULL, out, "n", 1U, 4U, &v) == STATUS_ERR_NULL);
        CHECK(input_prompt_text(in, out, "t", NULL, 8U, name_ok) == STATUS_ERR_NULL);
        (void)fclose(in);
    }
    write_file(TMP_IN, "a\nb\nc\n");
    in = fopen(TMP_IN, "r");
    if (in != NULL) {
        CHECK(input_prompt_text(in, out, "t", text, sizeof(text), name_ok) == STATUS_OK); /* 'a' valid */
        (void)fclose(in);
    }
    write_file(TMP_IN, "|\n|\n|\n");
    in = fopen(TMP_IN, "r");
    if (in != NULL) {
        CHECK(input_prompt_text(in, out, "t", text, sizeof(text), name_ok) == STATUS_ERR_RANGE);
        (void)fclose(in);
    }
    (void)fclose(out);
    (void)remove(TMP_FILE);
    (void)remove(TMP_IN);
}

static void fill_sample(bst_t *t)
{
    const station_id_t ids[] = {500U, 250U, 750U, 120U, 300U};
    size_t i; station_t s;
    for (i = 0U; i < 5U; i++) {
        (void)station_init(&s, ids[i], "Stn", ids[i], ids[i] / 10U, 2U, "Relay");
        (void)bst_insert(t, &s);
    }
}

static void test_save_and_load_roundtrip(void)
{
    bst_t a; bst_t b; uint32_t n = 0U; station_id_t mn = 0U; station_id_t mx = 0U;
    const station_t *s;
    bst_init(&a); bst_init(&b);
    fill_sample(&a);
    CHECK(storage_save(&a, TMP_FILE) == STATUS_OK);
    CHECK(storage_save(&a, TMP_FILE) == STATUS_OK);              /* overwrite existing */
    CHECK(storage_load(&b, TMP_FILE) == STATUS_OK);
    CHECK(bst_stats(&b, &n, &mn, &mx) == STATUS_OK && n == 5U && mn == 120U && mx == 750U);
    s = bst_search(&b, 300U);
    CHECK(s != NULL && s->distance_km == 300U && strcmp(s->type, "Relay") == 0);
    CHECK(s != NULL && s->fare == 30U && s->platform == 2U);     /* fare + platform survive */
    CHECK(b.root->data.id == 500U);                              /* preorder keeps shape */
    /* loading replaces (and frees) previous content */
    bst_destroy(&a);
    CHECK(storage_load(&b, TMP_FILE) == STATUS_OK && b.count == 5U);
    bst_destroy(&b);
    /* saving an empty tree is valid and loads back as empty */
    bst_init(&a);
    CHECK(storage_save(&a, TMP_FILE) == STATUS_OK);
    CHECK(storage_load(&b, TMP_FILE) == STATUS_OK && b.count == 0U);
    (void)remove(TMP_FILE);
}

static void test_load_rejects_bad_files(void)
{
    bst_t t; uint32_t n; station_id_t mn; station_id_t mx;
    char longline[300];
    bst_init(&t); fill_sample(&t);
    CHECK(storage_load(&t, "no_such_file.txt") == STATUS_ERR_IO);
    write_file(TMP_FILE, "WRONG_HEADER\n1|A|1|B\n");
    CHECK(storage_load(&t, TMP_FILE) == STATUS_ERR_FORMAT);
    write_file(TMP_FILE, "");
    CHECK(storage_load(&t, TMP_FILE) == STATUS_ERR_FORMAT);
    write_file(TMP_FILE, "STATIONS_V2\n1|A|1|10|1|B\n1|C|2|10|1|D\n");           /* duplicate id */
    CHECK(storage_load(&t, TMP_FILE) == STATUS_ERR_DUPLICATE);
    write_file(TMP_FILE, "STATIONS_V2\n1|A|1\n");                      /* too few fields */
    CHECK(storage_load(&t, TMP_FILE) == STATUS_ERR_FORMAT);
    write_file(TMP_FILE, "STATIONS_V2\n1|A|1|10|1|B|extra\n");              /* too many fields */
    CHECK(storage_load(&t, TMP_FILE) == STATUS_ERR_FORMAT);
    write_file(TMP_FILE, "STATIONS_V2\nabc|A|1|10|1|B\n");                  /* bad id text */
    CHECK(storage_load(&t, TMP_FILE) == STATUS_ERR_FORMAT);
    write_file(TMP_FILE, "STATIONS_V2\n-4|A|1|10|1|B\n");
    CHECK(storage_load(&t, TMP_FILE) == STATUS_ERR_FORMAT);
    write_file(TMP_FILE, "STATIONS_V2\n1|A|xyz|10|1|B\n");                  /* bad distance */
    CHECK(storage_load(&t, TMP_FILE) == STATUS_ERR_FORMAT);
    write_file(TMP_FILE, "STATIONS_V2\n0|A|1|10|1|B\n");                    /* id out of range */
    CHECK(storage_load(&t, TMP_FILE) == STATUS_ERR_FORMAT);
    write_file(TMP_FILE, "STATIONS_V2\n1|A@|1|10|1|B\n");                   /* illegal char */
    CHECK(storage_load(&t, TMP_FILE) == STATUS_ERR_FORMAT);
    /* fare / platform field errors and the retired V1 layout */
    write_file(TMP_FILE, "STATIONS_V2\n1|A|1|xyz|1|B\n");               /* bad fare text */
    CHECK(storage_load(&t, TMP_FILE) == STATUS_ERR_FORMAT);
    write_file(TMP_FILE, "STATIONS_V2\n1|A|1|100001|1|B\n");            /* fare too high */
    CHECK(storage_load(&t, TMP_FILE) == STATUS_ERR_FORMAT);
    write_file(TMP_FILE, "STATIONS_V2\n1|A|1|10|0|B\n");                /* platform too low */
    CHECK(storage_load(&t, TMP_FILE) == STATUS_ERR_FORMAT);
    write_file(TMP_FILE, "STATIONS_V2\n1|A|1|10|100|B\n");               /* platform too high */
    CHECK(storage_load(&t, TMP_FILE) == STATUS_ERR_FORMAT);
    write_file(TMP_FILE, "STATIONS_V1\n1|A|1|B\n");                    /* old header */
    CHECK(storage_load(&t, TMP_FILE) == STATUS_ERR_FORMAT);
    write_file(TMP_FILE, "STATIONS_V2\n1|A|1|B\n");                    /* 4-field record */
    CHECK(storage_load(&t, TMP_FILE) == STATUS_ERR_FORMAT);
    (void)memset(longline, 'x', sizeof(longline)); longline[299] = '\0';
    write_file(TMP_FILE, "STATIONS_V2\n");
    { FILE *f = fopen(TMP_FILE, "a"); if (f != NULL) { (void)fputs(longline, f); (void)fputs("\n", f); (void)fclose(f); } }
    CHECK(storage_load(&t, TMP_FILE) == STATUS_ERR_FORMAT);            /* over-long line */
    CHECK(storage_load(NULL, TMP_FILE) == STATUS_ERR_NULL);
    CHECK(storage_load(&t, NULL) == STATUS_ERR_NULL);
    /* every failed load left the original tree untouched */
    CHECK(bst_stats(&t, &n, &mn, &mx) == STATUS_OK && n == 5U);
    /* comments, blank lines, CRLF and a missing final newline are accepted */
    write_file(TMP_FILE, "# c\n\nSTATIONS_V2\r\n# x\n7|Seven|7|10|1|Core\r\n\n8|Eight|8|10|1|Core");
    CHECK(storage_load(&t, TMP_FILE) == STATUS_OK && t.count == 2U);
    bst_destroy(&t);
    (void)remove(TMP_FILE);
}

static void test_save_errors(void)
{
    bst_t t; char longpath[300];
    bst_init(&t); fill_sample(&t);
    CHECK(storage_save(NULL, TMP_FILE) == STATUS_ERR_NULL);
    CHECK(storage_save(&t, NULL) == STATUS_ERR_NULL);
    CHECK(storage_save(&t, "") == STATUS_ERR_RANGE);
    (void)memset(longpath, 'p', sizeof(longpath)); longpath[299] = '\0';
    CHECK(storage_save(&t, longpath) == STATUS_ERR_RANGE);
    CHECK(storage_save(&t, "no_such_dir/stations.txt") == STATUS_ERR_IO);
    bst_destroy(&t);
}

static void test_sample_data_file_and_functional_flow(void)
{
    bst_t t; sw_config_t c; sw_stats_t st; station_id_t bad = 0U; status_t rc;
    bst_init(&t);
    rc = storage_load(&t, "data/stations.txt");                 /* run from project root */
    CHECK(rc == STATUS_OK && t.count == 7U);
    /* full functional flow: validate endpoints, then transmit */
    CHECK(station_validate_endpoints(&t, 500U, 250U, &bad) == STATUS_OK);
    (void)sw_config_default(&c);
    CHECK(sw_simulate(&c, 500U, 250U, NULL, &st) == STATUS_OK);
    CHECK(st.delivered == c.packet_count);
    /* invalid endpoints never reach the simulator */
    CHECK(station_validate_endpoints(&t, 500U, 4242U, &bad) == STATUS_ERR_NOT_FOUND);
    /* add -> update -> delete cycle */
    { station_t s; CHECK(station_init(&s, 777U, "New", 5U, 100U, 1U, "Core") == STATUS_OK);
      CHECK(bst_insert(&t, &s) == STATUS_OK); }
    CHECK(bst_update(&t, 777U, "Renamed", 6U, 100U, 1U, "Relay") == STATUS_OK);
    CHECK(strcmp(bst_search(&t, 777U)->name, "Renamed") == 0);
    CHECK(bst_search(&t, 777U)->fare == 100U && bst_search(&t, 777U)->platform == 1U);
    CHECK(bst_update(&t, 777U, "Renamed", 6U, 250U, 7U, "Relay") == STATUS_OK);
    CHECK(bst_search(&t, 777U)->fare == 250U && bst_search(&t, 777U)->platform == 7U);
    CHECK(bst_delete(&t, 777U) == STATUS_OK && bst_search(&t, 777U) == NULL);
    bst_destroy(&t);
}

static void test_status_strings(void)
{
    int i;
    for (i = 0; i <= (int)STATUS_ERR_MAX_RETRIES; i++) {
        const char *m = status_to_string((status_t)i);
        CHECK(m != NULL && m[0] != '\0' && strcmp(m, "unknown error") != 0);
    }
    CHECK(strcmp(status_to_string((status_t)999), "unknown error") == 0);
}

int main(void)
{
    RUN_TEST(test_station_validation);
    RUN_TEST(test_fare_and_platform_validation);
    RUN_TEST(test_endpoint_validation);
    RUN_TEST(test_parse_u32);
    RUN_TEST(test_read_line);
    RUN_TEST(test_prompts);
    RUN_TEST(test_save_and_load_roundtrip);
    RUN_TEST(test_load_rejects_bad_files);
    RUN_TEST(test_save_errors);
    RUN_TEST(test_sample_data_file_and_functional_flow);
    RUN_TEST(test_status_strings);
    return TEST_SUMMARY();
}
